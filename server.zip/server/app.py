import os
from flask import Flask, send_from_directory, jsonify, request
from flask_cors import CORS

# Point Flask to the 'build' folder you just moved here
app = Flask(__name__, static_folder='build', static_url_path='')
CORS(app)

# --- YOUR EXISTING API ROUTES GO HERE ---
# (Keep all your existing @app.route('/api/...') functions exactly as they are)

# --- NEW: Serve React Frontend ---
@app.route('/')
def serve():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/<path:path>')
def static_proxy(path):
    # This serves static files (js/css) or falls back to index.html for React Router
    if os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    return send_from_directory(app.static_folder, 'index.html')

if __name__ == '__main__':
    # '0.0.0.0' allows other computers on the network to see it (optional)
    app.run(host='0.0.0.0', port=5001, debug=True)